package com.finorix.pro

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.widget.*
import android.text.InputType
import java.util.Locale
import kotlin.random.Random

/**
 * Finorix Pro is a self-contained educational demo.
 * Quotes are simulated and no trades are sent to a broker.
 */
class MainActivity : Activity() {
    private var balance = 10000.0
    private var price = 1.0850
    private var selectedAsset = "EUR/USD"
    private val history = mutableListOf<Double>()
    private lateinit var balanceLabel: TextView
    private lateinit var quoteLabel: TextView
    private lateinit var chart: PriceChart
    private lateinit var historyLabel: TextView
    private lateinit var amountInput: EditText
    private val bg = Color.rgb(12, 18, 34)
    private val panel = Color.rgb(24, 34, 54)
    private val green = Color.rgb(37, 211, 153)
    private val red = Color.rgb(255, 94, 112)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        balance = savedInstanceState?.getDouble("balance") ?: 10000.0
        price = savedInstanceState?.getDouble("price") ?: 1.0850
        selectedAsset = savedInstanceState?.getString("asset") ?: "EUR/USD"
        repeat(35) { history.add(price + Random.nextDouble(-0.003, 0.003)) }
        if (getPreferences(MODE_PRIVATE).getBoolean("entered", false)) dashboard() else login()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putDouble("balance", balance)
        outState.putDouble("price", price)
        outState.putString("asset", selectedAsset)
        super.onSaveInstanceState(outState)
    }

    private fun label(text: String, size: Float = 17f, color: Int = Color.WHITE): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            setPadding(8, 12, 8, 12)
        }

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 36, 24, 28)
        setBackgroundColor(bg)
    }

    private fun input(hint: String): EditText = EditText(this).apply {
        this.hint = hint
        setHintTextColor(Color.LTGRAY)
        setTextColor(Color.WHITE)
        setSingleLine(true)
    }

    private fun button(text: String, color: Int, click: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
            setOnClickListener { click() }
        }

    private fun login() {
        val box = column()
        box.addView(label("FINORIX PRO", 32f, green))
        box.addView(label("Demo trading simulator • No real money", 15f))
        val name = input("Your name")
        box.addView(name)
        box.addView(button("Enter Demo", green) {
            if (name.text.toString().trim().isEmpty()) {
                name.error = "Enter your name"
            } else {
                getPreferences(MODE_PRIVATE).edit()
                    .putBoolean("entered", true).putString("name", name.text.toString().trim()).apply()
                dashboard()
            }
        })
        box.addView(label("No account or password needed. This app does not connect to a broker.", 13f, Color.LTGRAY))
        setContentView(box)
    }

    private fun dashboard() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val box = column()
        scroll.addView(box)
        box.addView(label("FINORIX PRO", 29f, green))
        box.addView(label("DEMO MODE — simulated prices, virtual funds only", 13f, Color.YELLOW))
        box.addView(label("Hello, " + getPreferences(MODE_PRIVATE).getString("name", "Trader"), 16f))
        balanceLabel = label("", 27f)
        box.addView(balanceLabel)
        refreshBalance()
        val assets = arrayOf("EUR/USD", "GBP/USD", "BTC/USD (demo)", "XAU/USD (demo)")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, assets)
        spinner.setSelection(assets.indexOf(selectedAsset).coerceAtLeast(0))
        box.addView(spinner)
        quoteLabel = label("", 23f)
        box.addView(quoteLabel)
        chart = PriceChart()
        box.addView(chart, LinearLayout.LayoutParams(-1, 320))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, pos: Int, id: Long) {
                selectedAsset = assets[pos]
                price = when(pos) { 0 -> 1.085; 1 -> 1.335; 2 -> 65000.0; else -> 2700.0 }
                history.clear()
                repeat(35) { history.add(price * (1 + Random.nextDouble(-0.008, 0.008))) }
                refreshQuote()
            }
        }
        box.addView(button("Update simulated price", panel) {
            price *= 1 + Random.nextDouble(-0.006, 0.006)
            history.add(price)
            if (history.size > 60) history.removeAt(0)
            refreshQuote()
        })
        box.addView(label("Trade amount (virtual USD)", 16f))
        amountInput = input("e.g. 100").apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText("100")
        }
        box.addView(amountInput)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("BUY ↑", green) { trade(true) }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(button("SELL ↓", red) { trade(false) }, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(actions)
        box.addView(label("Demo rule: each trade resolves instantly against a newly simulated price. Win +80% of stake; loss −100%. This is not a real market model.", 12f, Color.LTGRAY))
        historyLabel = label("Trade history\nNo trades yet", 14f)
        box.addView(historyLabel)
        box.addView(button("Reset virtual balance", panel) {
            balance = 10000.0
            refreshBalance()
            historyLabel.text = "Trade history\nBalance reset"
        })
        box.addView(button("Sign out", panel) {
            getPreferences(MODE_PRIVATE).edit().clear().apply()
            login()
        })
        refreshQuote()
        setContentView(scroll)
    }

    private fun refreshBalance() {
        balanceLabel.text = String.format(Locale.US, "Virtual balance: $%,.2f", balance)
    }

    private fun refreshQuote() {
        quoteLabel.text = String.format(Locale.US, "%s  %,.4f", selectedAsset, price)
        chart.invalidate()
    }

    private fun trade(buy: Boolean) {
        val stake = amountInput.text.toString().toDoubleOrNull()
        if (stake == null || !stake.isFinite() || stake <= 0 || stake > balance) {
            amountInput.error = "Enter an amount between 0 and your virtual balance"
            return
        }
        val old = price
        price *= 1 + Random.nextDouble(-0.006, 0.006)
        history.add(price)
        if (history.size > 60) history.removeAt(0)
        val won = if (buy) price > old else price < old
        val pnl = if (won) stake * 0.8 else -stake
        balance += pnl
        refreshBalance()
        refreshQuote()
        val result = String.format(Locale.US, "%s %s $%.2f → %s $%+.2f",
            selectedAsset, if (buy) "BUY" else "SELL", stake,
            if (won) "WIN" else "LOSS", pnl)
        historyLabel.text = "Trade history\n$result\n" +
            historyLabel.text.toString().removePrefix("Trade history\n").take(1500)
    }

    inner class PriceChart : View(this) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = green; strokeWidth = 4f; style = Paint.Style.STROKE
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(panel)
            if (history.size < 2) return
            val min = history.minOrNull() ?: return
            val max = history.maxOrNull() ?: return
            val range = (max - min).coerceAtLeast(0.00000001)
            val path = android.graphics.Path()
            history.forEachIndexed { i, p ->
                val x = 12f + i * (width - 24f) / (history.size - 1)
                val y = (height - 20f) - ((p - min) / range * (height - 40f)).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
        }
    }
}
