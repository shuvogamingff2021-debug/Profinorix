# Finorix Pro — Demo Android app

Educational simulator only. Quotes are random and simulated. No live market data,
broker integration, real money, deposits, withdrawals or real trading.

## Build an APK without Android Studio
1. Create a GitHub repository.
2. Upload **the contents of this ZIP** to the repository root (including `.github`).
3. Open **Actions** → **Build Android APK** → **Run workflow**.
4. Once green, open the run and download `FinorixPro-debug-apk` under **Artifacts**.
5. Extract the artifact ZIP and install `app-debug.apk` on your Android phone.

The workflow also runs when you push to `main` or `master`.
You can build locally with JDK 17, Android SDK 35, Gradle 8.9: `gradle assembleDebug`.
This project intentionally does not implement real-money trading or store passwords.
